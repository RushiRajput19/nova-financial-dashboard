# Nova Financial — Personal Finance Dashboard (Clone)

A static clone of [Nova Financial](https://financialdash.ccbp.tech/), built as part of a web development internship project. The goal was to replicate the layout, components, and interactivity of the reference dashboard using only HTML, CSS, and Bootstrap 5.

## Live Demo
[Add your deployed link here after deploying]

## Features
- Responsive sidebar navigation with an off-canvas mobile drawer
- Dashboard overview with balance, income, expense, and savings summary cards
- Spending activity chart with Week / Month toggle (Chart.js)
- Quick Transfer panel with selectable contacts
- Recent transactions table with All / Income / Expense filtering
- Spending by category (doughnut chart) and monthly budget progress bars
- Income vs Expenses comparison chart
- Recurring subscriptions list
- Card management section with a daily spending limit slider
- Dark mode toggle (persisted via localStorage) — added as an extra feature beyond the original site

## Tech Stack
- HTML5
- CSS3 (custom properties / design tokens, BEM-style class naming)
- Bootstrap 5 (grid + utilities)
- Vanilla JavaScript
- Chart.js (for data visualizations)

## Project Structure
```
nova-financial/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── script.js
└── assets/
```

## Running Locally
Just open `index.html` in a browser, or serve it locally:
```bash
python3 -m http.server 8080
```
Then visit `http://localhost:8080`.

## Notes
This is a front-end static clone built for learning purposes — all transaction and chart data is mock/dummy data, and there is no backend or authentication.
