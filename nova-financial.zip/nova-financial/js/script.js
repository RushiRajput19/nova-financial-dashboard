// ==========================================================================
// Sidebar toggle (mobile)
// ==========================================================================
const sidebar = document.getElementById('sidebar');
const sidebarToggle = document.getElementById('sidebarToggle');
const sidebarOverlay = document.getElementById('sidebarOverlay');

function closeSidebar() {
  sidebar.classList.remove('open');
  sidebarOverlay.classList.remove('show');
}

sidebarToggle?.addEventListener('click', () => {
  sidebar.classList.toggle('open');
  sidebarOverlay.classList.toggle('show');
});
sidebarOverlay?.addEventListener('click', closeSidebar);

document.querySelectorAll('.sidebar__link').forEach(link => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    document.querySelectorAll('.sidebar__link').forEach(l => l.classList.remove('active'));
    link.classList.add('active');
    closeSidebar();
  });
});

// ==========================================================================
// Dark mode toggle (creative-liberty feature)
// ==========================================================================
const themeToggle = document.getElementById('themeToggle');
const root = document.documentElement;

function safeGet(key) { try { return localStorage.getItem(key); } catch { return null; } }
function safeSet(key, val) { try { localStorage.setItem(key, val); } catch {} }

function applyTheme(theme) {
  if (theme === 'dark') {
    root.setAttribute('data-theme', 'dark');
    themeToggle.innerHTML = '<i class="bi bi-sun-fill"></i>';
  } else {
    root.removeAttribute('data-theme');
    themeToggle.innerHTML = '<i class="bi bi-moon-stars-fill"></i>';
  }
  renderCharts();
}

applyTheme(safeGet('nova-theme') || 'light');
themeToggle?.addEventListener('click', () => {
  const next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  applyTheme(next);
  safeSet('nova-theme', next);
});

// ==========================================================================
// Mock data
// ==========================================================================
const activityData = {
  week: { labels: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'], values: [320, 450, 280, 500, 620, 190, 260] },
  month: { labels: ['Wk 1','Wk 2','Wk 3','Wk 4'], values: [2100, 1950, 2400, 1790] }
};

const ieData = {
  labels: ['Jan','Feb','Mar','Apr','May','Jun'],
  income: [7200, 6800, 8100, 7600, 8400, 8249],
  expense: [3200, 3400, 2900, 3600, 3100, 3842]
};

const categoryData = {
  labels: ['Food & Dining', 'Shopping', 'Transport', 'Bills & Utilities', 'Entertainment'],
  values: [620, 410, 180, 990, 260],
  colors: ['#4F46E5', '#7A5AF8', '#17B26A', '#F79009', '#F04438']
};

const transactions = [
  { merchant: 'Amazon', icon: 'bi-bag-fill', category: 'Shopping', date: 'Aug 28, 2026', amount: -84.50, status: 'completed', type: 'expense' },
  { merchant: 'Salary Deposit', icon: 'bi-cash-coin', category: 'Income', date: 'Aug 27, 2026', amount: 4200.00, status: 'completed', type: 'income' },
  { merchant: 'Starbucks', icon: 'bi-cup-hot-fill', category: 'Food & Dining', date: 'Aug 26, 2026', amount: -6.75, status: 'completed', type: 'expense' },
  { merchant: 'Electric Company', icon: 'bi-lightning-charge-fill', category: 'Bills & Utilities', date: 'Aug 25, 2026', amount: -142.30, status: 'pending', type: 'expense' },
  { merchant: 'Uber', icon: 'bi-car-front-fill', category: 'Transport', date: 'Aug 24, 2026', amount: -23.10, status: 'completed', type: 'expense' },
  { merchant: 'Freelance Payment', icon: 'bi-briefcase-fill', category: 'Income', date: 'Aug 23, 2026', amount: 650.00, status: 'completed', type: 'income' },
  { merchant: 'Netflix', icon: 'bi-tv-fill', category: 'Entertainment', date: 'Aug 22, 2026', amount: -15.99, status: 'failed', type: 'expense' },
  { merchant: 'Grocery Store', icon: 'bi-basket3-fill', category: 'Food & Dining', date: 'Aug 21, 2026', amount: -96.42, status: 'completed', type: 'expense' }
];

// ==========================================================================
// Charts
// ==========================================================================
let activityChart, categoryChart, ieChart;

function themeColors() {
  const dark = root.getAttribute('data-theme') === 'dark';
  return { grid: dark ? 'rgba(255,255,255,0.06)' : 'rgba(18,20,43,0.06)', text: dark ? '#8B8FA8' : '#6B7089' };
}

function renderCharts() {
  const colors = themeColors();
  const range = document.querySelector('.filter-btn.active')?.dataset.range || 'week';
  const activity = activityData[range];

  const actCtx = document.getElementById('spendingActivityChart');
  if (activityChart) activityChart.destroy();
  activityChart = new Chart(actCtx, {
    type: 'line',
    data: {
      labels: activity.labels,
      datasets: [{
        label: 'Spending',
        data: activity.values,
        borderColor: '#4F46E5',
        backgroundColor: 'rgba(79,70,229,0.12)',
        fill: true,
        tension: 0.35,
        pointRadius: 3
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { display: false }, ticks: { color: colors.text } },
        y: { grid: { color: colors.grid }, ticks: { color: colors.text } }
      }
    }
  });

  const catCtx = document.getElementById('categoryChart');
  if (categoryChart) categoryChart.destroy();
  categoryChart = new Chart(catCtx, {
    type: 'doughnut',
    data: { labels: categoryData.labels, datasets: [{ data: categoryData.values, backgroundColor: categoryData.colors, borderWidth: 0 }] },
    options: { responsive: true, cutout: '70%', plugins: { legend: { display: false } } }
  });
  renderCategoryLegend();

  const ieCtx = document.getElementById('incomeExpenseChart');
  if (ieChart) ieChart.destroy();
  ieChart = new Chart(ieCtx, {
    type: 'bar',
    data: {
      labels: ieData.labels,
      datasets: [
        { label: 'Income', data: ieData.income, backgroundColor: '#4F46E5', borderRadius: 6, maxBarThickness: 16 },
        { label: 'Expenses', data: ieData.expense, backgroundColor: '#F04438', borderRadius: 6, maxBarThickness: 16 }
      ]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { display: false }, ticks: { color: colors.text, font: { size: 10 } } },
        y: { grid: { color: colors.grid }, ticks: { color: colors.text, font: { size: 10 } } }
      }
    }
  });
}

function renderCategoryLegend() {
  const legend = document.getElementById('categoryLegend');
  const total = categoryData.values.reduce((a, b) => a + b, 0);
  legend.innerHTML = categoryData.labels.map((label, i) => {
    const pct = ((categoryData.values[i] / total) * 100).toFixed(0);
    return `<li><span class="dot" style="background:${categoryData.colors[i]}"></span> ${label} <span style="margin-left:auto; font-weight:600; color:var(--color-text)">${pct}%</span></li>`;
  }).join('');
}

document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderCharts();
  });
});

// ==========================================================================
// Transactions table + filter chips
// ==========================================================================
function renderTransactions(filter = 'all') {
  const tbody = document.querySelector('#txnTable tbody');
  const rows = transactions.filter(t => filter === 'all' || t.type === filter);
  tbody.innerHTML = rows.map(t => `
    <tr>
      <td><div class="merchant-cell"><span class="merchant-icon"><i class="bi ${t.icon}"></i></span>${t.merchant}</div></td>
      <td>${t.category}</td>
      <td>${t.date}</td>
      <td class="text-end ${t.amount > 0 ? 'amount-positive' : 'amount-negative'}">${t.amount > 0 ? '+' : '-'}$${Math.abs(t.amount).toFixed(2)}</td>
      <td><span class="status-pill ${t.status}">${t.status.charAt(0).toUpperCase() + t.status.slice(1)}</span></td>
    </tr>
  `).join('');
}

document.querySelectorAll('.chip[data-filter]').forEach(chip => {
  chip.addEventListener('click', () => {
    document.querySelectorAll('.chip[data-filter]').forEach(c => c.classList.remove('active'));
    chip.classList.add('active');
    renderTransactions(chip.dataset.filter);
  });
});

// ==========================================================================
// Quick transfer avatar select
// ==========================================================================
document.querySelectorAll('.qt-avatar').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.qt-avatar').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
  });
});

// ==========================================================================
// Card settings slider
// ==========================================================================
const spendLimit = document.getElementById('spendLimit');
const spendLimitValue = document.getElementById('spendLimitValue');
spendLimit?.addEventListener('input', () => {
  spendLimitValue.textContent = `$${Number(spendLimit.value).toLocaleString()}`;
});

// ==========================================================================
// Init
// ==========================================================================
renderCharts();
renderTransactions();
